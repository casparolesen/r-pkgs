print <- function (file) {
  dataset <- readr::read_csv(file, skip = 5, col_names = c("Kommune", "Antal flygtninge"))
  View(dataset)
  
  save(dataset, file = "mydata.Rdata")
}
